﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TaskCart.Modal
{
    public class MockCartRepository : ICartRepository
    {
        private List<Cart> _cart = new List<Cart>();
       
        public MockCartRepository() {
            _cart.Add(new Cart() {id =1, CartName = "Amazon", ShoppingType= "E-com", CartType = "COD",NoOfItems= 1,TypeOfItems="Casual" });
            _cart.Add(new Cart() { id = 2, CartName = "Neupass", ShoppingType = "E'-com", CartType = "COD", NoOfItems = 1, TypeOfItems = "Casual" });
        }
        Cart ICartRepository.GetCart(int id) {   
            return _cart.FirstOrDefault(e => e.id == id);
        }
    }
}
