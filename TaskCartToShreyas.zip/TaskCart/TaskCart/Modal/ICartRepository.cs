﻿

namespace TaskCart.Modal
{
    public interface ICartRepository
    {
        Cart GetCart(int id);
    }
}
